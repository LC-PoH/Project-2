// ========== AUTHENTICATION & UTILITIES ==========

// Toggle password visibility
function togglePassword() {
    const passwordInput = document.getElementById('password');
    const eyeIcon = document.getElementById('eyeIcon');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
    } else {
        passwordInput.type = 'password';
    }
}

// Handle login
function handleLogin(event) {
    event.preventDefault();
    
    const role = document.getElementById('role').value;
    const username = document.getElementById('username').value;
    
    // Store user data in sessionStorage
    sessionStorage.setItem('userRole', role);
    sessionStorage.setItem('userName', username);
    
    // Show notification
    showNotification(`Welcome ${username}! Redirecting...`, 'success');
    
    // Redirect based on role
    setTimeout(() => {
        if (role === 'student') {
            window.location.href = 'student-dashboard.html';
        } else if (role === 'owner') {
            window.location.href = 'owner-dashboard.html';
        } else if (role === 'receptionist') {
            window.location.href = 'receptionist-dashboard.html';
        }
    }, 1000);
}

// Logout function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        sessionStorage.clear();
        showNotification('You have been logged out!', 'success');
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 500);
    }
}

// Check authentication
function checkAuth() {
    const userRole = sessionStorage.getItem('userRole');
    if (!userRole) {
        window.location.href = 'index.html';
    }
    return userRole;
}

// Get user name
function getUserName() {
    return sessionStorage.getItem('userName') || 'User';
}

// ========== MODAL FUNCTIONS ==========

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = 'auto';
    }
}

// Close modal when clicking outside
document.addEventListener('click', function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.classList.remove('active');
        document.body.style.overflow = 'auto';
    }
});

// ========== NOTIFICATIONS ==========

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#10b981' : '#ef4444'};
        color: white;
        padding: 1rem 2rem;
        border-radius: 0.75rem;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 2000;
        animation: slideIn 0.3s ease-out;
        font-weight: 500;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// ========== FORM HANDLERS ==========

function handleCheckIn(event) {
    event.preventDefault();
    showNotification('✓ Student checked in successfully!', 'success');
    if (event.target.closest('.modal')) {
        closeModal(event.target.closest('.modal').id);
    }
    event.target.reset();
}

function handleCheckOut(event) {
    event.preventDefault();
    showNotification('✓ Student checked out successfully!', 'success');
    if (event.target.closest('.modal')) {
        closeModal(event.target.closest('.modal').id);
    }
    event.target.reset();
}

function handleRegister(event) {
    event.preventDefault();
    showNotification('✓ Student registered successfully!', 'success');
    if (event.target.closest('.modal')) {
        closeModal(event.target.closest('.modal').id);
    }
    event.target.reset();
}

function handlePayment(event) {
    event.preventDefault();
    showNotification('✓ Payment processed successfully!', 'success');
    if (event.target.closest('.modal')) {
        closeModal(event.target.closest('.modal').id);
    }
    event.target.reset();
}

function handleRoomAdd(event) {
    event.preventDefault();
    showNotification('✓ Room added successfully!', 'success');
    if (event.target.closest('.modal')) {
        closeModal(event.target.closest('.modal').id);
    }
    event.target.reset();
}

function handleStudentAdd(event) {
    event.preventDefault();
    showNotification('✓ Student registered successfully!', 'success');
    if (event.target.closest('.modal')) {
        closeModal(event.target.closest('.modal').id);
    }
    event.target.reset();
}

function handleRoomChange(event) {
    event.preventDefault();
    showNotification('✓ Room change request submitted!', 'success');
    if (event.target.closest('.modal')) {
        closeModal(event.target.closest('.modal').id);
    }
    event.target.reset();
}

function handleComplaint(event) {
    event.preventDefault();
    showNotification('✓ Your complaint has been submitted!', 'success');
    if (event.target.closest('.modal')) {
        closeModal(event.target.closest('.modal').id);
    }
    event.target.reset();
}

function handleRequest(event) {
    event.preventDefault();
    showNotification('✓ Your request has been submitted!', 'success');
    if (event.target.closest('.modal')) {
        closeModal(event.target.closest('.modal').id);
    }
    event.target.reset();
}

function handleProfileUpdate(event) {
    event.preventDefault();
    showNotification('✓ Profile updated successfully!', 'success');
    event.target.reset();
}

// ========== NAVIGATION ==========

function setActivePage(event, pageId) {
    // Handle event parameter for onclick handlers
    if (event && event.preventDefault) {
        event.preventDefault();
    }
    
    // If first parameter is a string (legacy calls), treat it as pageId
    if (typeof event === 'string') {
        pageId = event;
    }
    
    // Remove active class from all nav items
    document.querySelectorAll('.sidebar-menu a').forEach(link => {
        link.classList.remove('active');
    });
    
    // Add active class to current page link
    const activeLink = document.querySelector(`[data-page="${pageId}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }
    
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.style.display = 'none';
    });
    
    // Show current page
    const currentPage = document.getElementById(pageId);
    if (currentPage) {
        currentPage.style.display = 'block';
    }
}

// ========== DASHBOARD INITIALIZATION ==========

function initDashboard() {
    try {
        const userRole = checkAuth();
        const userName = getUserName();
        
        // Update user info in navbar
        const userNameEl = document.getElementById('userName');
        const userRoleEl = document.getElementById('userRole');
        
        if (userNameEl) {
            userNameEl.textContent = userName || 'User';
        }
        if (userRoleEl) {
            userRoleEl.textContent = userRole || 'User';
        }
        
        // Show dashboard page by default
        setActivePage(null, 'dashboardPage');
    } catch (error) {
        console.error('Error initializing dashboard:', error);
    }
}

// ========== CHARTS & VISUALIZATION ==========

function initRevenueChart() {
    const ctx = document.getElementById('revenueChart');
    if (!ctx) return;
    
    if (typeof Chart !== 'undefined') {
        try {
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                    datasets: [{
                        label: 'Monthly Revenue',
                        data: [180000, 195000, 225000, 210000, 240000, 225000],
                        borderColor: '#667eea',
                        backgroundColor: 'rgba(102, 126, 234, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4,
                        pointBackgroundColor: '#667eea',
                        pointBorderColor: '#fff',
                        pointBorderWidth: 2,
                        pointRadius: 5
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { display: true }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        } catch (error) {
            console.error('Error initializing revenue chart:', error);
        }
    }
}

// ========== DATA EXPORT ==========

function exportToCSV(tableId, filename) {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    let csv = [];
    for (let row of table.rows) {
        let rowData = [];
        for (let cell of row.cells) {
            rowData.push('"' + cell.innerText + '"');
        }
        csv.push(rowData.join(','));
    }
    
    let csvContent = csv.join('\n');
    let element = document.createElement('a');
    element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvContent));
    element.setAttribute('download', filename || 'export.csv');
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
}

// ========== UTILITY FUNCTIONS ==========

function formatCurrency(amount) {
    return '₹' + amount.toLocaleString('en-IN');
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
    });
}

// ========== PAGE LOAD EVENT ==========

document.addEventListener('DOMContentLoaded', function() {
    // Run initialization on dashboard pages
    if (document.querySelector('.dashboard-container')) {
        initDashboard();
        setTimeout(() => initRevenueChart(), 500);
    }
});

// Fallback: Initialize on window load if DOMContentLoaded doesn't fire
window.addEventListener('load', () => {
    if (document.body.classList.contains('dashboard')) {
        setTimeout(initDashboard, 200);
        setTimeout(initRevenueChart, 500);
    }
});
